
"use strict";
const menuButton = document.querySelector("[data-menu]");
const nav = document.querySelector("[data-nav]");
if (menuButton && nav) {
  menuButton.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
  });
}
const search = document.querySelector("[data-tool-search]");
const filters = document.querySelectorAll("[data-filter]");
const tools = document.querySelectorAll("[data-tool]");
let activeCategory = "all";
function applyToolFilter(){
  const query = (search?.value || "").trim().toLowerCase();
  tools.forEach(card => {
    const matchesText = card.textContent.toLowerCase().includes(query);
    const matchesCategory = activeCategory === "all" || card.dataset.category === activeCategory;
    card.hidden = !(matchesText && matchesCategory);
  });
}
search?.addEventListener("input", applyToolFilter);
filters.forEach(btn => btn.addEventListener("click", () => {
  filters.forEach(x => x.classList.remove("active"));
  btn.classList.add("active");
  activeCategory = btn.dataset.filter || "all";
  applyToolFilter();
}));
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}
