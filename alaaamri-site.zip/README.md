# alaaamri.com

Upload the contents of this folder to Cloudflare Pages.

Recommended Cloudflare Pages settings:
- Framework preset: None
- Build command: leave empty
- Build output directory: /
- Always Use HTTPS: On
- Minimum TLS Version: TLS 1.2 or newer

Files:
- index.html: Portfolio home
- projects.html: Projects
- tech-hub.html: Curated technical resources
- _headers: Security headers for Cloudflare Pages
- manifest.webmanifest + sw.js: Installable PWA support

Before publishing:
1. Review the experience numbers and wording.
2. Add your real LinkedIn/GitHub URLs when available.
3. Add a CV file only after removing sensitive personal information.
